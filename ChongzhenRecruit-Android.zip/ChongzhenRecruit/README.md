# 崇祯直聘 Android 封装项目

这是一个原生 Android WebView 外壳，启动后加载：

- https://wtd85afh.mule.page/

## 已实现

- JavaScript、DOM Storage、Cookie 与网页存档支持
- 网页音频播放支持
- Android 返回键优先返回网页上一页
- 顶部加载进度条
- 主页面加载失败提示与重试按钮
- 外部链接交给系统浏览器打开
- 文件选择器兼容
- 强制竖屏、全屏显示
- 仅允许 HTTPS 明文禁用

## Android Studio 编译

1. 使用 Android Studio 打开项目根目录 `ChongzhenRecruit`。
2. 等待 Gradle Sync 完成。
3. 确认已安装 Android SDK 35 与 JDK 17。
4. 选择 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
5. Debug APK 位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 发布签名

发布前使用 Android Studio 的 `Build > Generate Signed Bundle / APK` 创建或选择你自己的 keystore。不要把 keystore 密码提交到公开仓库。

## 注意

此版本是在线 WebView 封装，运行时需要联网。网页内容、更新和存档逻辑仍由原网站控制。公开发布前应确认你拥有该网页游戏、名称、图像、音乐及其他素材的封装和分发权。
